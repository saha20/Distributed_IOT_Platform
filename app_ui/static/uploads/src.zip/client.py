import requests
import json

req_name = input("Enter the request file name : ")
with open(req_name, "r") as f:
    json_data = json.loads(f.read())


print("data to send : ", json_data)
resp = requests.post('http://127.0.0.1:12212/user_req', json=json_data)
print(resp.json())
