from flask import Flask, jsonify
import socket

app = Flask(__name__)
function_names = ["get_sensor_data"]

@app.route('/', methods=['GET'])
def hello_word():
    return jsonify(function_names)

def get_sensor_data(sensor_id):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect(("127.0.0.1", 21212))
        msg = "CR|{}".format(sensor_id).encode("utf-8")
        sock.send(msg)

        resp_list = list()
        data = sock.recv(1024).decode()
        while len(data) > 0:
            resp_list.append(data)
            data = sock.recv(1024).decode()

        response = "".join(resp_list)
        response = eval(response)
        return response

@app.route('/<string:function>', methods=['GET'])
def call_function(function):
    fname, param = None, None
    if ':' in function:
        fname, param = function.split(":")
        param = eval(param)
    else:
        fname = function
    if fname in function_names:
        try:
            ret_val = None
            if param:
                ret_val = get_sensor_data(*param)
            else:
                ret_val = get_sensor_data(1)
            response = {'error' : False, 'value' : ret_val, 'type' :
                        str(type(ret_val))}
            return jsonify(response)
        except:
            return jsonify({'error': True, 'message': 'Check the input parameters.'})
    else:
        return jsonify({'error' : True, 'message' : 'Function name not found!'})


if __name__ == '__main__':
    app.run(debug = True)
