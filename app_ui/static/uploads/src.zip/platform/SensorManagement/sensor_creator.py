import json
import os
import threading

SENSOR_FILE_PATH = "./SensorManagement/sensor.py"
SENSOR_REGISTRATION_FILE_PATH = "./sensor_registration.json"

def spawn_sensor(sensor_id, freq, lower_bound, upper_bound):
    os.system("python {} {} {} {} {}".format(SENSOR_FILE_PATH, sensor_id, freq, lower_bound, upper_bound))

with open(SENSOR_REGISTRATION_FILE_PATH, "r") as f:
    data = json.loads(f.read().strip())
    for sensors in data["Sensors"]:
        sensor_id = data["Sensors"][sensors]["sensor_id"]
        freq = data["Sensors"][sensors]["output_frequency"]
        output_data_type = data["Sensors"][sensors]["sensor_data_type"]
        lower_bound = data["Sensors"][sensors]["lower_bound"]
        upper_bound = data["Sensors"][sensors]["upper_bound"]

        t = threading.Thread(target=spawn_sensor, args=(sensor_id, freq, lower_bound, upper_bound))
        t.start()
        print("Sensor created and running !")
