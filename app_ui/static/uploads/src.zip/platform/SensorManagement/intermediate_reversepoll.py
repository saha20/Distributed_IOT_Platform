import socket
import threading

SERVER_IP = "127.0.0.1"
SERVER_PORT = 21212

send_data = False
send_socket = None
want_for_sensor = None


def process_request(client_sock):
    global send_data
    global send_socket
    global want_for_sensor

    message = client_sock.recv(1024).decode()

    parts = message.split("|")
    if parts[0] == "RP":
        # this is the reverse polling signal
        if send_data:
            client_sock.send("W|{}".format(want_for_sensor).encode("utf-8"))
        else:
            client_sock.send("N".encode("utf-8"))
    elif parts[0] == "SD":
        # send Data signal
        send_socket.send(parts[1].encode("utf-8"))
        send_socket.close()
        send_data = False
        send_socket = None
        want_for_sensor = None
    elif parts[0] == "CR":
        # client Request signal
        send_data = True
        send_socket = client_sock
        want_for_sensor = parts[1]


if __name__ == '__main__':
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind((SERVER_IP, SERVER_PORT))
        sock.listen(8)

        while True:
            client_sock, addr = sock.accept()
            thr = threading.Thread(target = process_request, args = (client_sock, ))
            thr.start()

