from random import randint, choice
import sys
from time import sleep
import socket

if __name__ == '__main__':
    freq = 1
    sensor_id = 1
    lower_bound = 0
    upper_bound = 100

    if len(sys.argv) != 5:
        print("Please provide all 4 commandline args : sensor_id, frequency, lower and upper bounds")
        sys.exit(0)

    sensor_id = int(sys.argv[1])
    freq = float(sys.argv[2])
    lower_bound = float(sys.argv[3])
    upper_bound = float(sys.argv[4])

    time_interval = 1/freq
    last = (upper_bound + lower_bound)/2
    gap = upper_bound - lower_bound + 1 #inclusive
    while True:
        if last == lower_bound:
            curr += randint(1, min(5, gap//3))
        elif last == upper_bound:
            curr -= randint(1, min(5, gap//3))
        inc_dec = choice([1, -1])
        curr = last + inc_dec * randint(1, gap//2) * (randint(1, 100)/100)
        if curr > upper_bound:
            curr = upper_bound
        elif curr < lower_bound:
            curr = lower_bound
        last = curr
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect(("127.0.0.1", 33333))
            message = "{} {}".format(sensor_id, curr)
            sock.send(message.encode("utf-8"))
        sleep(time_interval)
