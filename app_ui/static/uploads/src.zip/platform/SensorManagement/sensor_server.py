import socket
from collections import defaultdict
import threading
from time import sleep


POLLING_INTERVAL = 0.1 #in seconds

data_lock = False
sensor_data = defaultdict(list)

def start_reversepolling(polling_interval=1):
    global data_lock
    intermediate_ip = "127.0.0.1"
    intermediate_port = 21212

    send_data = False
    sensor_id = None

    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as polling_sock:
            polling_sock.connect((intermediate_ip, intermediate_port))
            if send_data:
                if int(sensor_id) not in sensor_data:
                    message = "SD|[]"
                else:
                    while data_lock:
                        pass
                    data_lock = True
                    message = "SD|{}".format(sensor_data[sensor_id])
                    #sensor_data[sensor_id].clear()
                    data_lock = False
            else:
                message = "RP"
            polling_sock.send(message.encode("utf-8"))
            if send_data:
                send_data = False
                sensor_id = None
            else:
                resp = polling_sock.recv(128).decode()
                if resp[0] == "W":
                    parts = resp.split("|")
                    sensor_id = int(parts[1])
                    send_data = True

        if not send_data:
            sleep(polling_interval)

if __name__ == '__main__':
    #Start up the poller
    polling_thread = threading.Thread(target = start_reversepolling, args=(POLLING_INTERVAL,))
    polling_thread.daemon = True
    polling_thread.start()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 33333))
        listener.listen(8)

        while True:
            sensor_conn, addr = listener.accept()
            message_part = list()
            data = sensor_conn.recv(256).decode()
            while len(data) > 0:
                message_part.append(data)
                data = sensor_conn.recv(256).decode()
            message = "".join(message_part)
            sensor_id, reading = message.split()
            while data_lock:
                pass
            data_lock = True
            sensor_data[int(sensor_id)].clear()
            sensor_data[int(sensor_id)].append(float(reading))
            data_lock = False
            sensor_conn.close()
