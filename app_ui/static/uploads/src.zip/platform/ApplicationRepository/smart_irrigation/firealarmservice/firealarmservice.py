from rpc import RPC

r = RPC()
smoke_level = r.get_sensor_data(4)[0]
temperature  = r.get_sensor_data(5)[0]

if smoke_level>50:
    print("sound_alarm")
else:
    print("no alarm")
