import socket
import json

class RPC:
    def __init__(self):
        function_list = json.loads(self.__get_request_server_pylon("/").decode())
        for fname in function_list:
            fname = fname.strip()
            if fname.startswith('_'):
                continue
            self.__setattr__(fname, self.generate_stub_function(fname))

    def generate_stub_function(self, fname):
        def random_function(*args):
            str_args = str(args).strip().replace(" ", "")
            if len(str_args) > 0:
                request_path = "/{}:{}".format(fname, str_args)
            else:
                request_path = "/{}".format(fname)
            result = self.__get_request_server_pylon(request_path)
            result = json.loads(result.decode())
            if result['error']:
                raise Exception(result['message'])
            ret_val = result['value']
            if result['type'] != str(type(ret_val)):
                raise Exception("Return Type cannot be parsed properly")
            return ret_val
        return random_function

    def __get_request_server_pylon(self, request_path):
        result = None
        with socket.socket() as sock:
            sock.connect(('127.0.0.1', 5000))
            request = "GET {} HTTP/1.1\n\n".format(request_path)
            sock.send(request.encode("utf-8"))
            resp = list()
            r = sock.recv(1024)
            while len(r) > 0:
                resp.append(r)
                r = sock.recv(1024)
            result = b"".join(resp).split(b"\r\n\r\n", 1)[1]
        return result
