from rpc import RPC

r = RPC()
soil_moisture = r.get_sensor_data(1)[0]
air_moisture = r.get_sensor_data(2)[0]

if soil_moisture>20 and air_moisture<100:
    print("start dripping of water")
else:
    print("no dripping")

