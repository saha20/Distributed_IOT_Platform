from rpc import RPC

r = RPC()
temperature  = r.get_sensor_data(3)[0]

if temperature>40:
    print("increase temperature")
else:
    print("decrease temperature")

