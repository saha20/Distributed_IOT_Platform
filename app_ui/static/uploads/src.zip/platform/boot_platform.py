import os
import threading

FILE_PREFIX = "./SensorManagement/"

def start_file(fname):
    os.system("python {}".format(fname))

if __name__ == '__main__':
    file_names = ["intermediate_RPC.py", "intermediate_reversepoll.py", "sensor_server.py", "sensor_creator.py"]
    for fname in file_names:
        target_file = os.path.join(FILE_PREFIX, fname)
        threading.Thread(target=start_file, args=(target_file,)).start()
        print("{} launched !".format(fname))

    threading.Thread(target=start_file, args=("deployer.py",)).start()
    print("{} launched !".format(fname))
