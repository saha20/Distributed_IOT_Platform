import os
from flask import Flask, jsonify, request
import subprocess

app = Flask(__name__)

@app.route('/user_req', methods=['POST'])
def manage_request():
    json_data = request.json
    resp = {}
    for apps in json_data:
        app_name = json_data[apps]["application_name"]
        resp[app_name] = dict()
        for services in json_data[apps]["services"]:
            service_name = json_data[apps]["services"][services]["service_name"]
            fname = json_data[apps]["services"][services]["filename"]
            file_path = "./ApplicationRepository/{}/{}/{}".format(app_name, service_name, fname)
            op1 = subprocess.run(['python', file_path], capture_output=True, text=True)
            resp[app_name][service_name] = op1.stdout
    return jsonify(resp)

if __name__ == "__main__":
    app.run(debug=True, port=12212)


